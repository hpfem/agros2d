#include "hermes2d.h"

NeighborSearch::NeighborSearch(Element* el, Mesh* mesh) :
  supported_shapes(NULL),
  mesh(mesh),
  central_el(el),
  neighb_el(NULL),
  quad(&g_quad_2d_std)
{
  memset(central_transformations, 0, max_neighbors*max_n_trans*sizeof(unsigned int));
  memset(neighbor_transformations, 0, max_neighbors*max_n_trans*sizeof(unsigned int));
  memset(central_n_trans, 0, max_neighbors*sizeof(unsigned int));
  memset(neighbor_n_trans, 0, max_neighbors*sizeof(unsigned int));

  assert_msg(central_el != NULL && central_el->active == 1,
             "You must pass an active element to the NeighborSearch constructor.");
  neighbors.reserve(2);
  neighbor_edges.reserve(2);
    
  ignore_errors = false;
  n_neighbors = 0;
  neighborhood_type = H2D_DG_NOT_INITIALIZED;
  original_central_el_transform = 0;
}

NeighborSearch::NeighborSearch(const NeighborSearch& ns) :
  supported_shapes(NULL),
  mesh(ns.mesh),
  central_el(ns.central_el),
  neighb_el(NULL),
  neighbor_edge(ns.neighbor_edge),
  active_segment(ns.active_segment)
{
  _F_
  memset(central_transformations, 0, max_neighbors*max_n_trans*sizeof(unsigned int));
  memset(neighbor_transformations, 0, max_neighbors*max_n_trans*sizeof(unsigned int));
  memset(central_n_trans, 0, max_neighbors*sizeof(unsigned int));
  memset(neighbor_n_trans, 0, max_neighbors*sizeof(unsigned int));

  neighbors.reserve(2);
  neighbor_edges.reserve(2);

  for(unsigned int i = 0; i < ns.n_neighbors; i++)
    for(unsigned int j = 0; j < ns.central_n_trans[i]; j++)
      this->central_transformations[i][j] = ns.central_transformations[i][j];

  for(unsigned int i = 0; i < ns.n_neighbors; i++)
    this->central_n_trans[i] = ns.central_n_trans[i];

  for(unsigned int i = 0; i < ns.n_neighbors; i++)
    for(unsigned int j = 0; j < ns.neighbor_n_trans[i]; j++)
      this->neighbor_transformations[i][j] = ns.neighbor_transformations[i][j];

  for(unsigned int i = 0; i < ns.n_neighbors; i++)
    this->neighbor_n_trans[i] = ns.neighbor_n_trans[i];

  assert_msg(central_el != NULL && central_el->active == 1,
             "You must pass an active element to the NeighborSearch constructor.");

  for(unsigned int i = 0; i < ns.neighbors.size(); i++)
    this->neighbors.push_back(ns.neighbors[i]);
  for(unsigned int i = 0; i < ns.neighbor_edges.size(); i++)
    this->neighbor_edges.push_back(ns.neighbor_edges[i]);
  
  ignore_errors = ns.ignore_errors;
  n_neighbors = ns.n_neighbors;
  neighborhood_type = ns.neighborhood_type;
  original_central_el_transform = ns.original_central_el_transform;
  quad = (&g_quad_2d_std);
  active_edge = ns.active_edge;
}

NeighborSearch::~NeighborSearch()
{
  _F_
  neighbor_edges.clear();
  neighbors.clear();
  clear_supported_shapes();
}

void NeighborSearch::reset_neighb_info()
{
  _F_
  // Reset information about the neighborhood's active state.
  active_segment = 0;
  active_edge = 0;
  neighb_el = NULL;
  neighbor_edge.local_num_of_edge = 0;

  // Clear vectors with neighbor elements and their edge info for the active edge.
  neighbor_edges.clear();
  neighbors.clear();
  n_neighbors = 0;

  // Reset transformations.
  memset(central_transformations, 0, max_neighbors*max_n_trans*sizeof(unsigned int));
  memset(neighbor_transformations, 0, max_neighbors*max_n_trans*sizeof(unsigned int));
  memset(central_n_trans, 0, max_neighbors*sizeof(unsigned int));
  memset(neighbor_n_trans, 0, max_neighbors*sizeof(unsigned int));
  neighborhood_type = H2D_DG_NOT_INITIALIZED;
}

void NeighborSearch::set_active_edge(int edge)
{
  _F_
  reset_neighb_info();
  active_edge = edge;

  //debug_log("central element: %d", central_el->id);
  if (central_el->en[active_edge]->bnd == 0)
  {
    neighb_el = central_el->get_neighbor(active_edge);

    // First case : The neighboring element is of the same size as the central one.
    if (neighb_el != NULL)
    {
      //debug_log("active neighbor el: %d", neighb_el->id);

      // Get local number of the edge used by the neighbor.
      for (unsigned int j = 0; j < neighb_el->nvert; j++)
        if (central_el->en[active_edge] == neighb_el->en[j])
        {
          neighbor_edge.local_num_of_edge = j;
          break;
        }

      NeighborEdgeInfo local_edge_info;
      local_edge_info.local_num_of_edge = neighbor_edge.local_num_of_edge;

      // Query the orientation of the neighbor edge relative to the central el.
      int p1 = central_el->vn[active_edge]->id;
      int p2 = central_el->vn[(active_edge + 1) % central_el->nvert]->id;
      local_edge_info.orientation = neighbor_edge_orientation(p1, p2, 0);

      neighbor_edges.push_back(local_edge_info);

      // There is only one neighbor in this case.
      n_neighbors = 1;
      neighbors.push_back(neighb_el);

      // No need for transformation, since the neighboring element is of the same size.
      neighborhood_type = H2D_DG_NO_TRANSF;
    }
    else
    {
      // Peek the vertex in the middle of the active edge (if there is none, vertex will be NULL).
      Node* vertex = mesh->peek_vertex_node(central_el->en[active_edge]->p1,  central_el->en[active_edge]->p2);

      // Endpoints of the active edge.
      int orig_vertex_id[2];
      orig_vertex_id[0] = central_el->vn[active_edge]->id;
      orig_vertex_id[1]  = central_el->vn[(active_edge + 1) % central_el->nvert]->id;

      if (vertex == NULL)
      {
        neighborhood_type = H2D_DG_GO_UP;

        Element* parent = central_el->parent;

        // Array of middle-point vertices of the intermediate parent edges that we climb up to the correct parent element.
        Node** par_mid_vertices = new Node*[max_n_trans];
        // Number of visited intermediate parents.
        int n_parents = 0;

        for (unsigned int j = 0; j < max_n_trans; j++)
          par_mid_vertices[j] = NULL;

        find_act_elem_up(parent, orig_vertex_id, par_mid_vertices, n_parents);

        delete[] par_mid_vertices;
      }
      else
      {
        neighborhood_type = H2D_DG_GO_DOWN;

        int sons[max_n_trans]; // array of virtual sons of the central el. visited on the way down to the neighbor
        int n_sons = 0; // number of used transformations

        // Start the search by going down to the first son.
        find_act_elem_down( vertex, orig_vertex_id, sons, n_sons+1);

        //debug_log("number of neighbors on the way down: %d ", n_neighbors);
      }
    }
  }
  else
    if(!ignore_errors)
      error("The given edge isn't inner");
}

void NeighborSearch::set_active_edge_multimesh(const int& edge)
{
  _F_
  Hermes::vector<unsigned int> transformations = get_transforms(original_central_el_transform);
  // Inter-element edge.
  if(is_inter_edge(edge, transformations)) {
    set_active_edge(edge);
    update_according_to_sub_idx(transformations);
  }
  // Intra-element edge.
  else {
    neighb_el = central_el;
    
    for(unsigned int i = 0; i < transformations.size(); i++)
      neighbor_transformations[0][i] = transformations[i];
    neighbor_n_trans[0] = transformations.size();

    neighbor_edge.local_num_of_edge = active_edge = edge;
    NeighborEdgeInfo local_edge_info;
    local_edge_info.local_num_of_edge = neighbor_edge.local_num_of_edge;
    //! The "opposite" view of the same edge has the same orientation.
    local_edge_info.orientation = 0;
    neighbor_edges.push_back(local_edge_info);

    n_neighbors = 1;
    neighbors.push_back(neighb_el);
    neighborhood_type = H2D_DG_NO_TRANSF;
  }
  return;
}

Hermes::vector<unsigned int> NeighborSearch::get_transforms(uint64_t sub_idx)
{
  _F_
  Hermes::vector<unsigned int> transformations_backwards;
  while (sub_idx > 0) {
    transformations_backwards.push_back((sub_idx - 1) & 7);
    sub_idx = (sub_idx - 1) >> 3;
  }
  Hermes::vector<unsigned int> transformations;
  for(unsigned int i = 0; i < transformations_backwards.size(); i++)
    transformations.push_back(transformations_backwards[transformations_backwards.size() - 1 - i]);

  return transformations;
}

bool NeighborSearch::is_inter_edge(const int& edge, const Hermes::vector<unsigned int>& transformations)
{
  _F_
  // No subelements => of course this edge is an inter-element one.
  if(transformations.size() == 0)
    return true;

  // Triangles.
  for(unsigned int i = 0; i < transformations.size(); i++)
    if(central_el->get_mode() == HERMES_MODE_TRIANGLE) {
      if ((edge == 0 && (transformations[i] == 2 || transformations[i] == 3)) ||
          (edge == 1 && (transformations[i] == 0 || transformations[i] == 3)) ||
          (edge == 2 && (transformations[i] == 1 || transformations[i] == 3)))
        return false;
    }
    // Quads.
    else {
      if ((edge == 0 && (transformations[i] == 2 || transformations[i] == 3 || transformations[i] == 5)) ||
          (edge == 1 && (transformations[i] == 0 || transformations[i] == 3 || transformations[i] == 6)) ||
          (edge == 2 && (transformations[i] == 0 || transformations[i] == 1 || transformations[i] == 4)) ||
          (edge == 3 && (transformations[i] == 1 || transformations[i] == 2 || transformations[i] == 7)))
        return false;
    }
  return true;
}

void NeighborSearch::update_according_to_sub_idx(const Hermes::vector<unsigned int>& transformations)
{
  _F_
  if(neighborhood_type == H2D_DG_NO_TRANSF || neighborhood_type == H2D_DG_GO_UP) {
    for(unsigned int i = 0; i < transformations.size(); i++)
      // Triangles.
      if(central_el->get_mode() == HERMES_MODE_TRIANGLE)
        if ((active_edge == 0 && transformations[i] == 0) ||
            (active_edge == 1 && transformations[i] == 1) ||
            (active_edge == 2 && transformations[i] == 2))
          neighbor_transformations[0][neighbor_n_trans[0]++] = (!neighbor_edge.orientation ? neighbor_edge.local_num_of_edge : (neighbor_edge.local_num_of_edge + 1) % 3);
        else
          neighbor_transformations[0][neighbor_n_trans[0]++] = (neighbor_edges[0].orientation ? neighbor_edge.local_num_of_edge : (neighbor_edge.local_num_of_edge + 1) % 3);
      // Quads.
      else
        if ((active_edge == 0 && (transformations[i] == 0 || transformations[i] == 6)) ||
            (active_edge == 1 && (transformations[i] == 1 || transformations[i] == 4)) ||
            (active_edge == 2 && (transformations[i] == 2 || transformations[i] == 7)) ||
            (active_edge == 3 && (transformations[i] == 3 || transformations[i] == 5)))
          neighbor_transformations[0][neighbor_n_trans[0]++] = (!neighbor_edge.orientation ? neighbor_edge.local_num_of_edge : (neighbor_edge.local_num_of_edge + 1) % 4);
        else if ((active_edge == 0 && (transformations[i] == 1 || transformations[i] == 7)) ||
            (active_edge == 1 && (transformations[i] == 2 || transformations[i] == 5)) ||
            (active_edge == 2 && (transformations[i] == 3 || transformations[i] == 6)) ||
            (active_edge == 3 && (transformations[i] == 0 || transformations[i] == 4)))
          neighbor_transformations[0][neighbor_n_trans[0]++] = (neighbor_edge.orientation ? neighbor_edge.local_num_of_edge : (neighbor_edge.local_num_of_edge + 1) % 4);
  }
  else handle_sub_idx_way_down(transformations);
}

void NeighborSearch::handle_sub_idx_way_down(const Hermes::vector<unsigned int>& transformations)
{
  _F_
  Hermes::vector<unsigned int> neighbors_to_be_deleted;
  Hermes::vector<unsigned int> neighbors_not_to_be_deleted;

  // We basically identify the neighbors that are not compliant with the current sub-element mapping on the central element.
  for(unsigned int neighbor_i = 0; neighbor_i < n_neighbors; neighbor_i++) {
    bool deleted = false;
    for(unsigned int level = 0; level < std::min((unsigned int)transformations.size(), central_n_trans[neighbor_i]); level++)
      // If the found neighbor is not a neighbor of this subelement.
      if(!compatible_transformations(central_transformations[neighbor_i][level], transformations[level], active_edge)) {
        deleted = true;
        break;
      }
    if(deleted)
      neighbors_to_be_deleted.push_back(neighbor_i);
    else
      neighbors_not_to_be_deleted.push_back(neighbor_i);
  }

  // Now for the compliant ones, we need to adjust the transformations.
  for(unsigned int neighbors_not_to_be_deleted_i = 0; neighbors_not_to_be_deleted_i < neighbors_not_to_be_deleted.size(); neighbors_not_to_be_deleted_i++) {
    unsigned int neighbor_i = neighbors_not_to_be_deleted[neighbors_not_to_be_deleted_i];
    for(unsigned int level = 0; level < transformations.size(); level++) {
      // We want to use the transformations from assembling, because set_active_edge only uses bsplit.
      // But we have to be careful, if the original central element transformation was anisotropic and adjacent to the current active edge
      // we have to adjust the transformations (leave the bsplit from set_active_edge), so that we do not lose any information by assembling over
      // a too small subelement.
      if(!
          ((active_edge == 0 && transformations[level] == 4) ||
          (active_edge == 1 && transformations[level] == 7) ||
          (active_edge == 2 && transformations[level] == 5) ||
          (active_edge == 3 && transformations[level] == 6))
        ) {
          central_transformations[neighbor_i][level] = transformations[level];
          // Also if the transformation count is already bigger than central_n_trans, we need to raise it.
          if(level >= central_n_trans[neighbor_i])
            central_n_trans[neighbor_i] = level + 1;
      }
      // If we are already on a bigger (i.e. ~ way up) neighbor.
      if(central_n_trans[neighbor_i] == level + 1) {
        for(unsigned int i = level + 1; i < transformations.size(); i++)
          // Triangles.
          if(central_el->get_mode() == HERMES_MODE_TRIANGLE)
            if ((active_edge == 0 && transformations[i] == 0) ||
                (active_edge == 1 && transformations[i] == 1) ||
                (active_edge == 2 && transformations[i] == 2))
              neighbor_transformations[neighbor_i][neighbor_n_trans[i]++] = (!neighbor_edge.orientation ? neighbor_edge.local_num_of_edge : (neighbor_edge.local_num_of_edge + 1) % 3);
            else
              neighbor_transformations[neighbor_i][neighbor_n_trans[i]++] = (neighbor_edge.orientation ? neighbor_edge.local_num_of_edge : (neighbor_edge.local_num_of_edge + 1) % 3);
          // Quads.
          else
            if ((active_edge == 0 && (transformations[i] == 0 || transformations[i] == 6)) ||
                (active_edge == 1 && (transformations[i] == 1 || transformations[i] == 4)) ||
                (active_edge == 2 && (transformations[i] == 2 || transformations[i] == 7)) ||
                (active_edge == 3 && (transformations[i] == 3 || transformations[i] == 5)))
              neighbor_transformations[neighbor_i][neighbor_n_trans[neighbor_i]++] = (!neighbor_edge.orientation ? neighbor_edge.local_num_of_edge : (neighbor_edge.local_num_of_edge + 1) % 4);
            else if ((active_edge == 0 && (transformations[i] == 1 || transformations[i] == 7)) ||
                (active_edge == 1 && (transformations[i] == 2 || transformations[i] == 5)) ||
                (active_edge == 2 && (transformations[i] == 3 || transformations[i] == 6)) ||
                (active_edge == 3 && (transformations[i] == 0 || transformations[i] == 4)))
              neighbor_transformations[neighbor_i][neighbor_n_trans[neighbor_i]++] = (neighbor_edge.orientation ? neighbor_edge.local_num_of_edge : (neighbor_edge.local_num_of_edge + 1) % 4);
      }
    }
  }

  // Now we truly delete (in the reverse order) the neighbors.
  if(neighbors_to_be_deleted.size() > 0)
    for(unsigned int neighbors_to_be_deleted_i = neighbors_to_be_deleted.size(); neighbors_to_be_deleted_i >= 1; neighbors_to_be_deleted_i--)
      delete_neighbor(neighbors_to_be_deleted[neighbors_to_be_deleted_i - 1]);
}

bool NeighborSearch::compatible_transformations(unsigned int a, unsigned int b, int edge)
{
  _F_
  if(a == b)
    return true;
  if(edge == 0) {
    if ((a == 0 && (b == 6 || b == 4)) ||
        (a == 1 && (b == 7 || b == 4)))
      return true;
    else
      return false;
  }
  if(edge == 1) {
    if ((a == 1 && (b == 4 || b == 7)) ||
        (a == 2 && (b == 5 || b == 7)))
      return true;
    else
      return false;
  }
  if(edge == 2) {
    if ((a == 2 && (b == 7 || b == 5)) ||
        (a == 3 && (b == 6 || b == 5)))
      return true;
    else
      return false;
  }
  if(edge == 3) {
    if ((a == 3 && (b == 5 || b == 6)) ||
        (a == 0 && (b == 4 || b == 6)))
      return true;
    else
      return false;
  }
  return false;
}

void NeighborSearch::clear_initial_sub_idx()
{
  _F_
  if(neighborhood_type != H2D_DG_GO_DOWN)
    return;
  // Obtain the transformations sequence.
  Hermes::vector<unsigned int> transformations = get_transforms(original_central_el_transform);
  // Test for active element.
  if(transformations.empty())
    return;
  for(unsigned int i = 0; i < n_neighbors; i++) {
    // Find the index where the additional subelement mapping (on top of the initial one from assembling) starts.
    unsigned int j = 0;
    // Note that we do not have to test if central_transformations is empty or how long it is, because it has to be
    // longer than transformations (and that is tested).
    // Also the function compatible_transformations() does not have to be used, as now the array central_transformations
    // has been adjusted so that it contains the array transformations.
    while(central_transformations[i][j] == transformations[j])
      if(++j > transformations.size() - 1)
        break;
    // Create a new array of transformations.
    unsigned int* shifted_trfs = new unsigned int[max_n_trans];
    // Clear it.
    memset(shifted_trfs, 0, max_n_trans * sizeof(unsigned int));
    // Move the old one to the new one.
    for(unsigned int k = j; k < central_n_trans[i]; k++)
      shifted_trfs[k - j] = central_transformations[i][k];
    // Point to the new one.
    for(unsigned int l = 0; l < max_n_trans; l++)
      central_transformations[i][l] = shifted_trfs[l];
    // We also have to store the information about length of the transformation array for this neighbor.
    central_n_trans[i] -= j;
  }
}

void NeighborSearch::delete_neighbor(unsigned int position)
{
  _F_
  for(unsigned int i = position; i < n_neighbors - 1; i++)
    for(unsigned int j = 0; j < max_n_trans; j++)
      central_transformations[i][j] = central_transformations[i + 1][j];
  for(unsigned int j = 0; j < max_n_trans; j++)
    central_transformations[n_neighbors - 1][j] = 0;
  for(unsigned int i = position; i < n_neighbors - 1; i++)
    central_n_trans[i] = central_n_trans[i + 1];
  central_n_trans[n_neighbors - 1] = 0;

  for(unsigned int i = position; i < n_neighbors - 1; i++)
    for(unsigned int j = 0; j < max_n_trans; j++)
      neighbor_transformations[i][j] = neighbor_transformations[i + 1][j];
  for(unsigned int j = 0; j < max_n_trans; j++)
    neighbor_transformations[n_neighbors - 1][j] = 0;
  for(unsigned int i = position; i < n_neighbors - 1; i++)
    neighbor_n_trans[i] = neighbor_n_trans[i + 1];
  neighbor_n_trans[n_neighbors - 1] = 0;

  neighbor_edges.erase (neighbor_edges.begin() + position);
  neighbors.erase (neighbors.begin() + position);
  n_neighbors--;
}


void NeighborSearch::find_act_elem_up( Element* elem, int* orig_vertex_id, Node** par_mid_vertices, int n_parents)
{
  _F_
  Node* edge = NULL;
  Node* vertex = NULL;

  assert(n_parents <= (int)max_n_trans);

  // IDs of vertices bounding the current intermediate parent edge.
  int p1 = elem->vn[active_edge]->id;
  int p2 = elem->vn[(active_edge + 1) % elem->nvert]->id;

  int id_of_par_orient_1 = p1;
  int id_of_par_orient_2 = p2;

  // Find if p1 and p2 bound a used edge (used by the neighbor element).
  edge = mesh->peek_edge_node(p1, p2);

  // Add the vertex in the middle of the parent edge to the array of intermediate parent vertices. This is for
  // consequent transformation of functions on neighbor element.
  vertex = mesh->peek_vertex_node(p1, p2);
  if(vertex != NULL)
  {
    if (n_parents == 0)
      par_mid_vertices[n_parents++] = vertex;
    else
      if (n_parents == max_n_trans - 1)
        error("Maximum number of intermediate parents exceeded in NeighborSearch::finding_act_elem_up");
      else
        if(par_mid_vertices[n_parents - 1]->id != vertex->id)
          par_mid_vertices[n_parents++] = vertex;
  }

  if ((edge == NULL) || (central_el->en[active_edge]->id == edge->id))
  {
    // We have not yet found the parent of the central element completely adjacent to the neighbor.
    find_act_elem_up(elem->parent, orig_vertex_id, par_mid_vertices, n_parents);
  }
  else
  {
    for (int i = 0; i < 2; i++)
    {
      // Get a pointer to the active neighbor element.
      if ((edge->elem[i] != NULL) && (edge->elem[i]->active == 1))
      {
        neighb_el = edge->elem[i];  //debug_log("way up neighbor: %d", neighb_el->id);

        // Get local number of the edge used by the neighbor.
        neighbor_edge.local_num_of_edge = -1;
        for(unsigned int j = 0; j < neighb_el->nvert; j++)
          if(neighb_el->en[j] == edge)
          {
            neighbor_edge.local_num_of_edge = j;
            break;
          }
        if(neighbor_edge.local_num_of_edge == -1) error("Neighbor edge wasn't found");

        Node* n = NULL;

        // Add to the array of neighbor_transformations one that transforms central el. to its parent completely
        // adjacent to the single big neighbor.
        assert(n_neighbors == 0);
        
        neighbor_n_trans[n_neighbors] = n_parents;
            
        // Go back through the intermediate inactive parents down to the central element and stack corresponding
        // neighbor_transformations into the array 'neighbor_transformations'.
        for(int j = n_parents - 1; j > 0; j-- ) {
          n = mesh->peek_vertex_node(par_mid_vertices[j]->id, p1);
          if(n == NULL) {
            neighbor_transformations[n_neighbors][n_parents - j - 1] = neighbor_edge.local_num_of_edge;
            p1 = par_mid_vertices[j]->id;
          }
          else {
            if(n->id == par_mid_vertices[j-1]->id) {
              neighbor_transformations[n_neighbors][n_parents - j - 1] = (neighbor_edge.local_num_of_edge + 1) % neighb_el->nvert;
              p2 = par_mid_vertices[j]->id;
            }
            else {
              neighbor_transformations[n_neighbors][n_parents - j - 1] = neighbor_edge.local_num_of_edge;
              p1 = par_mid_vertices[j]->id;
            }
          }
        }

        // Final transformation to the central element itself.
        if (orig_vertex_id[0] == par_mid_vertices[0]->id)
          neighbor_transformations[n_neighbors][n_parents - 1] = neighbor_edge.local_num_of_edge;
        else
          neighbor_transformations[n_neighbors][n_parents - 1] = (neighbor_edge.local_num_of_edge + 1) % neighb_el->nvert;

        NeighborEdgeInfo local_edge_info;
        local_edge_info.local_num_of_edge = neighbor_edge.local_num_of_edge;

        // Query the orientation of the neighbor edge relative to the central el.
        local_edge_info.orientation = neighbor_edge_orientation(id_of_par_orient_1, id_of_par_orient_2, 0);

        neighbor_edges.push_back(local_edge_info);

        // There is only one neighbor,...
        n_neighbors = 1;

        // ...add it to the vector of neighbors.
        neighbors.push_back(neighb_el);
      }
    }
  }
}


void NeighborSearch::find_act_elem_down( Node* vertex, int* bounding_verts_id, int* sons, unsigned int n_sons)
{
  _F_
  int mid_vert = vertex->id; // ID of vertex in between vertices from par_vertex_id.
  int bnd_verts[2];
  bnd_verts[0] = bounding_verts_id[0];
  bnd_verts[1] = bounding_verts_id[1];

  assert(n_sons < max_n_trans);

  for (int i = 0; i < 2; i++)
  {
    sons[n_sons-1] = (active_edge + i) % central_el->nvert;

    // Try to get a pointer to the edge between the middle vertex and one of the vertices bounding the previously
    // tested segment.
    Node* edge = mesh->peek_edge_node(mid_vert, bnd_verts[i]);

    if (edge == NULL) // The edge is not used, i.e. there is no active element on either side.
    {
      // Get the middle vertex of this edge and try again on the segments into which this vertex splits the edge.
      Node * n = mesh->peek_vertex_node(mid_vert, bnd_verts[i]);
      if(n == NULL)
        error("wasn't able to find middle vertex");
      else
      {
        // Make sure the next visited segment has the same orientation as the original central element's active edge.
        if(i == 0)
          bounding_verts_id[1] = mid_vert;
        else
          bounding_verts_id[0] = mid_vert;

        find_act_elem_down( n, bounding_verts_id, sons, n_sons+1);

        bounding_verts_id[0] = bnd_verts[0];
        bounding_verts_id[1] = bnd_verts[1];
      }
    }
    else  // We have found a used edge, the active neighbor we are looking for is on one of its sides.
    {
      for (int j = 0; j < 2; j++)
      {
        if ((edge->elem[j] != NULL) && (edge->elem[j]->active == 1))
        {
          neighb_el = mesh->get_element(edge->elem[j]->id);  //debug_log("way down neighbor: %d", edge->elem[j]->id);

          // Get local number of the edge used by the neighbor.
          neighbor_edge.local_num_of_edge = -1;
          for(unsigned int k = 0; k < neighb_el->nvert; k++)
            if(neighb_el->en[k] == edge)
            {
              neighbor_edge.local_num_of_edge = k;
              break;
            }
          if(neighbor_edge.local_num_of_edge == -1) error("Neighbor edge wasn't found");

          // Construct the transformation path to the current neighbor.
          for(unsigned int k = 0; k < n_sons; k++)
            central_transformations[n_neighbors][k] = sons[k];

          central_n_trans[n_neighbors] = n_sons;

          NeighborEdgeInfo local_edge_info;
          local_edge_info.local_num_of_edge = neighbor_edge.local_num_of_edge;
          // Query the orientation of the neighbor edge relative to the central el.
          local_edge_info.orientation = neighbor_edge_orientation(bnd_verts[0], bnd_verts[1], i);

          neighbor_edges.push_back(local_edge_info);

          // Append the new neighbor.
          n_neighbors++;
          neighbors.push_back(neighb_el);
        }
      }
    }
  }
}

int NeighborSearch::neighbor_edge_orientation(int bounding_vert1, int bounding_vert2, int segment)
{
  _F_
  if (segment == 0)
  {
    // neighbor edge goes from parent1 to middle vertex
    if (neighb_el->vn[neighbor_edge.local_num_of_edge]->id != bounding_vert1)
      return 1; // orientation reversed
  }
  else
  {
    // neighbor edge goes from middle vertex to parent2
    if (neighb_el->vn[neighbor_edge.local_num_of_edge]->id == bounding_vert2)
      return 1; // orientation reversed
  }
  return 0;
}

NeighborSearch::ExtendedShapeset::ExtendedShapeset(const NeighborSearch::ExtendedShapeset & other) {
  this->central_al = new AsmList(*other.central_al);
  this->cnt = other.cnt;
  this->dof = other.dof;
  this->neighbor_al = new AsmList(*other.neighbor_al);
  this->combine_assembly_lists();
}

NeighborSearch::ExtendedShapeset* NeighborSearch::create_extended_asmlist(Space *space, AsmList* al)
{
  _F_
  if (supported_shapes == NULL)
    supported_shapes = new ExtendedShapeset(this, al, space);
  else
    supported_shapes->update(this, space);

  return supported_shapes;
}

NeighborSearch::ExtendedShapeset* NeighborSearch::create_extended_asmlist_multicomponent(Space *space, AsmList* al)
{
  _F_
  if (supported_shapes != NULL)
    delete supported_shapes;
  
  supported_shapes = new ExtendedShapeset(this, al, space);
  
  return new ExtendedShapeset(*supported_shapes);
}

void NeighborSearch::set_quad_order(int order)
{
  _F_
  quad->set_mode(neighbors[active_segment]->get_mode());
  neighb_quad.init(quad, quad->get_edge_points(neighbor_edge.local_num_of_edge, order));
  quad->set_mode(central_el->get_mode());
  central_quad.init(quad, quad->get_edge_points(active_edge, order));
}

int NeighborSearch::get_quad_eo(bool on_neighbor)
{
  _F_
  if (on_neighbor)
    return neighb_quad.eo;
  else
    return central_quad.eo;
}

DiscontinuousFunc<scalar>* NeighborSearch::init_ext_fn(MeshFunction* fu)
{
  _F_
  Func<scalar>* fn_central = init_fn(fu, get_quad_eo(false));

  uint64_t original_transform = fu->get_transform();

  // Change the active element of the function. Note that this also resets the transformations on the function.
  fu->set_active_element(neighbors[active_segment]);
  
  for(unsigned int i = 0; i < neighbor_n_trans[active_segment]; i++)
    fu->push_transform(neighbor_transformations[active_segment][i]);

  Func<scalar>* fn_neighbor = init_fn(fu, get_quad_eo(true));

  // Restore the original function.
  fu->set_active_element(central_el);
  fu->set_transform(original_transform);

  return new DiscontinuousFunc<scalar>(fn_central, fn_neighbor, (neighbor_edge.orientation == 1));

  //NOTE: This function is not very efficient, since it sets the active elements and possibly pushes transformations
  // for each mesh function in each cycle of the innermost assembly loop. This is neccessary because only in
  // this innermost cycle (in function DiscreteProblem::eval_form), we know the quadrature order (dependent on
  // the actual basis and test function), which is needed for creating the Func<scalar> objects via init_fn.
  // The reason for storing the central and neighbor values of any given function in these objects is that otherwise
  // we would have to have one independent copy of the function for each of the neighboring elements. However, it
  // could unify the way PrecalcShapesets and MeshFunctions are treated in NeighborSearch and maybe these additional
  // deep memory copying, performed only after setting the active edge part (before the nested loops over basis and
  // test functions), would be actually more efficient than this. This would require implementing copy for Filters.
}

int NeighborSearch::get_neighb_edge_number(int segment)
{
  if( (unsigned) segment >= neighbor_edges.size())
    error("given number is bigger than actual number of neighbors ");
  else
    return neighbor_edges[segment].local_num_of_edge;
  return 0;
}

int NeighborSearch::get_neighb_edge_orientation(int segment)
{
  if( (unsigned) segment >= neighbor_edges.size())
    error("given number is bigger than actual number of neighbors ");
  else
    return neighbor_edges[segment].orientation;
  return 0;
}



/*** _____________________________________________ EXTENDED SHAPESET _____________________________________________ ***/


NeighborSearch::ExtendedShapeset::ExtendedShapeset(NeighborSearch* neighborhood, AsmList* central_al, Space* space) :
  central_al(central_al)
{
  _F_
  neighbor_al = new AsmList();
  space->get_boundary_assembly_list(neighborhood->neighb_el, neighborhood->neighbor_edge.local_num_of_edge, neighbor_al);
  combine_assembly_lists();
}

void NeighborSearch::ExtendedShapeset::combine_assembly_lists()
{
  assert(central_al != NULL && neighbor_al != NULL);
  cnt = central_al->cnt + neighbor_al->cnt;
  dof = new int [cnt];
  memcpy(dof, central_al->dof, sizeof(int)*central_al->cnt);
  memcpy(dof + central_al->cnt, neighbor_al->dof, sizeof(int)*neighbor_al->cnt);
}
