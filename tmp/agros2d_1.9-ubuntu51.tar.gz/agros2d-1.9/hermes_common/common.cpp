#include "common.h"

// int CommandLineArgs::m_argc = 0;
// char** CommandLineArgs::m_argv = NULL;

