// Windows DLL export/import definitions
#define TEUCHOS_LIB_DLL_EXPORT
