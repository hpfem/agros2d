/**************************************************************************
**
** This file is part of Qt Creator
**
** Copyright (c) 2009 Nokia Corporation and/or its subsidiary(-ies).
**
** Contact:  Qt Software Information (qt-info@nokia.com)
**
** Commercial Usage
**
** Licensees holding valid Qt Commercial licenses may use this file in
** accordance with the Qt Commercial License Agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and Nokia.
**
** GNU Lesser General Public License Usage
**
** Alternatively, this file may be used under the terms of the GNU Lesser
** General Public License version 2.1 as published by the Free Software
** Foundation and appearing in the file LICENSE.LGPL included in the
** packaging of this file.  Please review the following information to
** ensure the GNU Lesser General Public License version 2.1 requirements
** will be met: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
**
** If you are unsure which license is appropriate for your use, please
** contact the sales department at qt-sales@nokia.com.
**
**************************************************************************/

#include "scripteditorhighlighter.h"

#include <QtCore/QSet>
#include <QtCore/QtAlgorithms>
#include <QtCore/QDebug>
#include <QSyntaxHighlighter>

#include <QTextBlock>
#include <QTextBlockUserData>

const int ParenthesisMatcherPropertyId = QTextFormat::UserProperty;
const int ErrorMarkerPropertyId = QTextFormat::UserProperty + 1;

TextBlockData::TextBlockData()
{
    logMessage("TextBlockData::TextBlockData()");

}

QVector<ParenthesisInfo *> TextBlockData::parentheses()
{
    logMessage("TextBlockData::parentheses()");

    return m_parentheses;
}

void TextBlockData::insert(ParenthesisInfo *info)
{
    logMessage("TextBlockData::insert()");

    int i = 0;
    while (i < m_parentheses.size() && info->position > m_parentheses.at(i)->position)
        ++i;

    m_parentheses.insert(i, info);
}

// ************************************************************************************************************

QScriptSyntaxHighlighter::QScriptSyntaxHighlighter(QTextDocument *parent) : QSyntaxHighlighter(parent)
{
    logMessage("QScriptSyntaxHighlighter::QScriptSyntaxHighlighter()");

    HighlightingRule rule;

    keywordFormat.setForeground(Qt::darkBlue);
    keywordFormat.setFontWeight(QFont::Bold);

    QStringList keywordPatterns;
    keywordPatterns << "and" << "assert" << "break" << "class" << "continue" << "def"
            << "del" << "elif" << "else" << "except" << "exec" << "finally"
            << "for" << "from" << "global" << "if" << "import" << "in"
            << "is" << "lambda" << "not" << "or" << "pass" << "print" << "raise"
            << "return" << "try" << "while" << "yield";

    foreach (const QString &pattern, keywordPatterns)
    {
        rule.pattern = QRegExp("\\b" + pattern + "\\b", Qt::CaseInsensitive);
        rule.format = keywordFormat;
        highlightingRules.append(rule);
    }

    classFormat.setFontWeight(QFont::Bold);
    classFormat.setForeground(Qt::darkMagenta);
    rule.pattern = QRegExp("\\bQ[A-Za-z]+\\b");
    rule.format = classFormat;
    highlightingRules.append(rule);

    singleLineCommentFormat.setForeground(Qt::red);
    rule.pattern = QRegExp("#[^\n]*");
    rule.format = singleLineCommentFormat;
    highlightingRules.append(rule);

    multiLineCommentFormat.setForeground(Qt::red);

    quotationFormat.setForeground(Qt::darkGreen);
    rule.pattern = QRegExp("\".*\"");
    rule.format = quotationFormat;
    highlightingRules.append(rule);

    functionFormat.setForeground(Qt::blue);
    rule.pattern = QRegExp("\\b[A-Za-z0-9_]+(?=\\()");
    rule.format = functionFormat;
    highlightingRules.append(rule);

    operatorFormat.setForeground(Qt::magenta);
    rule.pattern = QRegExp("[\\\\|\\<|\\>|\\=|\\!|\\+|\\-|\\*|\\/|\\%]+");
    rule.pattern.setMinimal(true);
    rule.format = operatorFormat;
    highlightingRules.append(rule);

    commentStartExpression = QRegExp("\"\"\"");
    commentEndExpression = QRegExp("\"\"\"");
}

void QScriptSyntaxHighlighter::highlightBlock(const QString &text)
{
    logMessage("QScriptSyntaxHighlighter::highlightBlock()");

    foreach (const HighlightingRule &rule, highlightingRules)
    {
        QRegExp expression(rule.pattern);
        int index = expression.indexIn(text);
        while (index >= 0)
        {
            int length = expression.matchedLength();
            setFormat(index, length, rule.format);
            index = expression.indexIn(text, index + length);
        }
    }
    setCurrentBlockState(0);

    int startIndex = 0;
    if (previousBlockState() != 1)
        startIndex = commentStartExpression.indexIn(text);

    while (startIndex >= 0)
    {
        int endIndex = commentEndExpression.indexIn(text, startIndex);
        int commentLength;
        if (endIndex == -1)
        {
            setCurrentBlockState(1);
            commentLength = text.length() - startIndex;
        }
        else
        {
            commentLength = endIndex - startIndex + commentEndExpression.matchedLength();
        }
        setFormat(startIndex, commentLength, multiLineCommentFormat);
        startIndex = commentStartExpression.indexIn(text, startIndex + commentLength);
    }

    // parenthesis
    highlightBlockParenthesis(text, '(', ')');
    //highlightBlockParenthesis(text, '[', ']');
    //highlightBlockParenthesis(text, '{', '}');
}

void QScriptSyntaxHighlighter::highlightBlockParenthesis(const QString &text, char left, char right)
{
    logMessage("QScriptSyntaxHighlighter::highlightBlockParenthesis()");

    TextBlockData *data = new TextBlockData();

    int leftPos = text.indexOf(left);
    while (leftPos != -1)
    {
        ParenthesisInfo *info = new ParenthesisInfo();
        info->character = left;
        info->position = leftPos;

        data->insert(info);
        leftPos = text.indexOf(left, leftPos + 1);
    }

    int rightPos = text.indexOf(right);
    while (rightPos != -1)
    {
        ParenthesisInfo *info = new ParenthesisInfo();
        info->character = right;
        info->position = rightPos;

        data->insert(info);
        rightPos = text.indexOf(right, rightPos + 1);
    }

    setCurrentBlockUserData(data);
}
